/* =============================================
   PORTFOLIO - MAIN JAVASCRIPT
   Bharath Chandra Lakdaram
============================================= */

document.addEventListener('DOMContentLoaded', function () {

  /* ---- Scroll Reveal ---- */
  const reveals = document.querySelectorAll('.reveal');
  if (reveals.length > 0) {
    const revealObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          const siblings = Array.from(entry.target.parentElement.children);
          const idx = siblings.indexOf(entry.target);
          entry.target.style.transitionDelay = (idx * 0.08) + 's';
          entry.target.classList.add('visible');
          revealObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

    reveals.forEach(el => revealObserver.observe(el));
  }

  /* ---- Skill Bar Animation ---- */
  const skillBars = document.querySelectorAll('.skill-bar-fill');
  if (skillBars.length > 0) {
    const barObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          const bar = entry.target;
          const target = bar.getAttribute('data-width');
          setTimeout(() => { bar.style.width = target + '%'; }, 300);
          barObserver.unobserve(bar);
        }
      });
    }, { threshold: 0.2 });
    skillBars.forEach(bar => barObserver.observe(bar));
  }

  /* ---- Active Nav Link ---- */
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.navbar-nav .nav-link').forEach(link => {
    const href = link.getAttribute('href');
    if (href === currentPage || (currentPage === '' && href === 'index.html')) {
      link.classList.add('active');
    }
  });

  /* ---- Contact Form ---- */
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const btn = contactForm.querySelector('button[type="submit"]');
      btn.disabled = true;
      btn.innerHTML = '<i class="bi bi-send me-2"></i>Sending...';
      setTimeout(() => {
        btn.innerHTML = '<i class="bi bi-check2 me-2"></i>Message Sent!';
        btn.style.background = '#2d6a4f';
        btn.style.borderColor = '#2d6a4f';
        contactForm.reset();
        setTimeout(() => {
          btn.disabled = false;
          btn.innerHTML = '<i class="bi bi-send me-2"></i>Send Message';
          btn.style.background = '';
          btn.style.borderColor = '';
        }, 3000);
      }, 1200);
    });
  }

  /* ---- Certificate Modal ---- */
  const certCards = document.querySelectorAll('.cert-card');
  const certModal = document.getElementById('certModal');
  if (certCards.length > 0 && certModal) {
    certCards.forEach(card => {
      card.addEventListener('click', function () {
        const title  = card.querySelector('.cert-name')?.textContent   || '';
        const issuer = card.querySelector('.cert-issuer')?.textContent || '';
        const type   = card.querySelector('.cert-type')?.textContent   || '';
        const iconEl = card.querySelector('.cert-thumb i');

        document.getElementById('certModalTitle').textContent  = title;
        document.getElementById('certModalIssuer').textContent = issuer;
        document.getElementById('certModalType').textContent   = type;
        if (iconEl) {
          document.getElementById('certModalIcon').className = iconEl.className;
        }

        new bootstrap.Modal(certModal).show();
      });
    });
  }

  /* ---- Navbar scroll shadow ---- */
  const navbar = document.querySelector('.navbar');
  if (navbar) {
    window.addEventListener('scroll', function () {
      navbar.style.boxShadow = window.scrollY > 50
        ? '0 4px 30px rgba(0,0,0,0.5)'
        : '';
    });
  }

});
